C370 Project

Developed by: Hamza Alkadir, Andrew Chang, Shiv Desai, Jooha Lee, Alejandro Pacheco, Raphael Palacio, Riyaa Randhawa.